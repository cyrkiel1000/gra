package tabela;

import java.sql.Date;
import java.sql.SQLException;

public class tabela {

	// odwzorowanie tabeli z bazy danych
	private String gracz_kolko;
	private String gracz_krzyzyk;
	private String wygrany;
	private Date data;
	@Override
	public String toString() {
		return "tabela [gracz_kolko=" + gracz_kolko + ", gracz_krzyzyk=" + gracz_krzyzyk + ", wygrany=" + wygrany
				+ ", data=" + data + "]";
	}
	public tabela(String gracz_kolko, String gracz_krzyzyk, String wygrany, Date data) {
		super();
		this.gracz_kolko = gracz_kolko;
		this.gracz_krzyzyk = gracz_krzyzyk;
		this.wygrany = wygrany;
		this.data = data;
	}
	public String getGracz_kolko() {
		return gracz_kolko;
	}
	public void setGracz_kolko(String gracz_kolko) {
		this.gracz_kolko = gracz_kolko;
	}
	public String getGracz_krzyzyk() {
		return gracz_krzyzyk;
	}
	public void setGracz_krzyzyk(String gracz_krzyzyk) {
		this.gracz_krzyzyk = gracz_krzyzyk;
	}
	public String getWygrany() {
		return wygrany;
	}
	public void setWygrany(String wygrany) {
		this.wygrany = wygrany;
	}
	public Date getData() {
		return data;
	}
	public void setData(Date data) {
		this.data = data;
	}
	public tabela(String gracz_kolko, String gracz_krzyzyk, String wygrany) {
		super();
		this.gracz_kolko = gracz_kolko;
		this.gracz_krzyzyk = gracz_krzyzyk;
		this.wygrany = wygrany;
	}
	
	
}