package baza;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class baza {
// podłączenie do bazy danych
public static final String DRIVER = "org.sqlite.JDBC";
    public static final String DB_URL = "jdbc:sqlite:biblioteka.sqlite";
	private static final String PreparedStatement = null;
 
    private Connection conn;
    private Statement stat;
 
    public baza() {
        try {
            Class.forName(baza.DRIVER);
        } catch (ClassNotFoundException e) {
            System.err.println("Brak sterownika JDBC");
            e.printStackTrace();
        }
 
        try {
            conn = DriverManager.getConnection(DB_URL);
            stat = conn.createStatement();
        } catch (SQLException e) {
            System.err.println("Problem z otwarciem polaczenia");
            e.printStackTrace();
        }
 
        createTables();
	
}
    
    // stworzenie tabeli
    public boolean createTables()  {
        String createtabela = "CREATE TABLE IF NOT EXISTS tabelka2 (id INTEGER PRIMARY KEY AUTOINCREMENT,"
                + " gracz_kolko   varchar(255) , gracz_krzyzyk  varchar(255) , wygrany  varchar(255) ,  data DATE )";
       
        try {
           
            stat.execute( createtabela);
            System.out.println("stworzono");
        } catch (SQLException e) {
            System.err.println("Blad przy tworzeniu tabeli");
            e.printStackTrace();
            return false;
        }
               return true;
    }
    

  // dodawanie rekordow do bazy
    public boolean inserttabela(String gracz_kolko, String gracz_krzyzyk, String wygrany ) {
        try {
            PreparedStatement prepStmt = conn.prepareStatement(
                    "insert into tabelka2 values (NULL, ?, ?, ?,  CURRENT_TIMESTAMP );");
            prepStmt.setString(1, gracz_kolko);
            prepStmt.setString(2, gracz_krzyzyk);
            prepStmt.setString(3, wygrany);
            prepStmt.execute();
            
            System.out.print("Dodano rekord");
        } catch (SQLException e) {
            System.err.println("Blad przy wstawianiu czytelnika");
            e.printStackTrace();
            return false;
        }
        return true;
    }
    
    // zamiana rekordow na tablice dwuwymiarową
public String [][] rekordy()
{
	
	String [][] error = new String[1][1];
	
	error[0][0]="blad";
	int w=0;
	String [][] wyniki = new String [5][100];
	
	try {
		int i=0;
		int j=0;
		
		ResultSet result = stat.executeQuery("SELECT * FROM tabelka2 ORDER BY data DESC LIMIT 20");
		
		
		
		 while(result.next())
         {
         	
		wyniki[i][j]=	 result.getString("gracz_kolko");
		i++;
		
		wyniki[i][j]=	 result.getString("gracz_krzyzyk");
				i++;
		wyniki[i][j]=	 result.getString("wygrany");
				i++;
		
		wyniki[i][j]=		result.getString("data");
		i++;
		;
		j++;
		i=0;
		
		w=j;
         }
		 String [][] wyniki1 = new String [5][w];
		 
		 

	        for (int z=0 ; z<5 ;z++)
	        {
	        	
	        	for (int x=0 ; x<w ; x++)
	        	{
	        		
	        		wyniki1[z][x] = wyniki[z][x];
	        	
	        	}
	         }
		 
		 return wyniki1;
		 
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		System.err.println("Blad z tablica");
		return error;
	}
	
	
	
	
	// zamknięcie podłczenia z bazą
}
public void closeConnection() {
    try {
        conn.close();
    } catch (SQLException e) {
        System.err.println("Problem z zamknieciem połaczenia");
        e.printStackTrace();
    }
}	
	
	
}
